### run.R --- 
##----------------------------------------------------------------------
## Author: Brice Ozenne
## Created: apr 17 2018 (16:24) 
## Version: 
## Last-Updated: apr 17 2018 (16:26) 
##           By: Brice Ozenne
##     Update #: 3
##----------------------------------------------------------------------
## 
### Commentary: 
## 
### Change Log:
##----------------------------------------------------------------------
## 
### Code:

path <- "c:/Users/hpl802/Documents/GitHub/BuyseTest/inst/TestCpp11/" ## change path here
setwd(path)

## source function
sourceCpp("fct.cpp")

## run function
useInitLists() ## output: "larry" "curly" "moe"

######################################################################
### run.R ends here
